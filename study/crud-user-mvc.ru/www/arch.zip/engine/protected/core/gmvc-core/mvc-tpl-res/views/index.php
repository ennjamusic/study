<div class="column1">
    <ul class="menu">
        <li><a href="<?=CApp::getLink(array("controller"=>"site","view"=>"index"))?>"><?=CApp::getTranslate("createUser")?></a></li>
        <li><a href="<?=CApp::getLink(array("controller"=>"site","view"=>"about"))?>"><?=CApp::getTranslate("allUsers")?></a></li>
        <li><a href="<?=CApp::getLink(array("controller"=>"site","view"=>"register"))?>"><?=CApp::getTranslate("translate")?></a></li>
    </ul>
</div>
<div class="column2">
    <p><?=__FILE__?></p>
</div>