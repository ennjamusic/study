<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>MVC-generator</title>
    <?=CApp::linkCss("/engine/protected/core/gmvc-core/template/css/style.css")?>
    <?=CApp::linkGoogleJQuery()?>
    <?=CApp::linkScriptJS("/engine/protected/core/gmvc-core/template/js/script.js")?>
</head>
<body>