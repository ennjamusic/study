    public function {act}Action() {
        $this->render("{act}","tpl");
    }