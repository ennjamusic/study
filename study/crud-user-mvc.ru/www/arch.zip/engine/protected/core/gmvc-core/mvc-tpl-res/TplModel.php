<?php

class TplModel extends CModel {

    protected $tableName="tpl";

} 