<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title><?=CApp::showTitle()?></title>
    <?=CApp::linkCss(TEMPLATE_PATH."css/style.css")?>

</head>
<body>